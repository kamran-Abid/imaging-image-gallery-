package com.example.imaging.Adapter

interface GalleryImageClickListener {
    fun onClick(position: Int)
}