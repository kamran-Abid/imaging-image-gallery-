package com.example.imaging.Adapter

data class Image (
    val imageUrl: String,
    val title: String
)